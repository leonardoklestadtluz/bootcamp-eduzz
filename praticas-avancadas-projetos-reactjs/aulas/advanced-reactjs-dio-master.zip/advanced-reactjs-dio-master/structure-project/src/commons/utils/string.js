export const sanitizeString = (str) => console.log('sanitize', str) 

export const removeSpace = (str) => str