export const MENU = [
  'gallery',
  'photos',
  'shop',
  'store',
  'bank'
]
