import Button from './Button'
import Calc from './Calc'
import PhotosGallery from './PhotosGallery'

export {
  Button,
  Calc,
  PhotosGallery
}