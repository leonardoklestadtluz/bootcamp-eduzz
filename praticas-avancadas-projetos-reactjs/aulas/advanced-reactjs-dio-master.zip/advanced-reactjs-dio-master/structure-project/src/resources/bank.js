import Api from './api'

function AddBank (data) {
  return Api.addBank(data)
}