import 'react-router' from 'react-router'
import BankContainer from '../containers/Bank'

export const bankRouter = [{
  component: BankContainer
}]