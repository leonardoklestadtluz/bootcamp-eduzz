import Bank from './bank'
import Users from './users'

export const routes = [
  ...Bank.
  ...Users
]